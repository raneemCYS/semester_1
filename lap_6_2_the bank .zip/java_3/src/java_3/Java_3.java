package java_3;
import java.util.Scanner;  
import java.lang.Math.*;
public class Java_3{
    

public static void main(String[]args){

Scanner R=new Scanner(System.in);
  
System.out.print("enter the radius :");
int rad=R.nextInt();

double area= Math.PI*Math.pow(rad, 2);

System.out.printf("the area :%.3f",area);
System.out.println();



}}








/* int a=2 ,b=2,z=2;
 z*=(--a)*(b--)+b;
     System.out.println(z);*/

/*System.out.print("what number is today?");
  int w=R.nextInt();
  switch (w){
      case 1 :System.out.print("its the first of the mounth!!!"); break;
      case 7 :System.out.print("its the first week of the mounth!!!"); break;
      case 30 :System.out.print("its the end of the mounth!!!"); break;
      
      default :
      System.out.print("doz");
}}
else
}
*/





